export const environment = {
  production: false,
 // apiUrl: 'https://localhost:44347/api/'
  apiUrl: 'https://localhost:59273/api/'
};

