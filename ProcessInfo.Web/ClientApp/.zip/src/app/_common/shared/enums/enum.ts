export enum UserType {
    User = 0,
    Admin = 1
}

export enum Environment {
    DEV = 0,
    QA = 1,
    UAT = 2,
    DR = 3,
    PROD = 4
}