export interface DataTableResponse {
    data: Array<any>;
    draw: number;
    totalRecordsFiltered: number;
    totalRecords: number;
}